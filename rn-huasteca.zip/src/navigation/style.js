export default {

    container: {
        backgroundColor: 'white',
        flex: 1,
    },

    bgContainer: {
        borderBottomWidth: 0.5,
        borderBottomColor: '#A0A0A0'
    },

    userContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 30
    },

    userImagen: {
        width: 70,
        height: 70,
        borderRadius: 35
    },

    camaraContainer: {
        justifyContent: 'center',
        alignItems: 'center'
    },

    camaraIcon: {
        width: 20,
        height: 20,
        position: 'absolute',
        left: 15,
        bottom: 3
    },

    userNombre: {
        marginVertical: 10,
    },

    userTitulo: {
        textAlign: 'center',
        fontWeight:'bold',
        fontSize: 16
    },

    userSubTitulo: {
        textAlign: 'center',
        fontSize: 11,
        color: '#a537fd',
        paddingVertical: 5,
    },
 
}