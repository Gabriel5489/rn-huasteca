export const API_URL = "http://192.168.0.5:80";
export const WEB_URL ="http://192.168.0.5:8000";
export const TOKEN = "token";
export const SEARCH_HISTORY = "HistorySearchHuasteca";
export const STRIPE_KEY_PUBLIC = 
"pk_test_51JCnbuGSqsqx8ql043l8sGme8ZMEb9UANUpPu4JkcxSXeHptP4eGXfDNxdpR4iPis5cxJl3hNTvZAGdWcMbVYN7v00aJ93rSHC";