import React, { Component } from 'react'
import { Text, ScrollView } from 'react-native'
import Favorito from '../componentes/Favorite/Favorite'

export default function Favorite() {
        return (
            <ScrollView>
                <Favorito></Favorito>
            </ScrollView>
        )
}
