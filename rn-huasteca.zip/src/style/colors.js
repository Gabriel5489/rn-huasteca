const colors = {
    success: "#4CAF50",
    primary: "#2196F3",
    warning: "#FF9800",
    danger:"#F44336",
    info:"#00B8D4",
    yellow:"#FFEB3B",
    green:"#4CAF50",
    indigo: "#3F51B5",
    dark: "#616161",
    fontLight: "#fff",
    bgLight: "#fff",
    bgDark: "#16222b",
    gray: "#E0E0E0",
    bluegrey: "#607D8B",
    redark4: "#B71C1C",
};
export default colors;